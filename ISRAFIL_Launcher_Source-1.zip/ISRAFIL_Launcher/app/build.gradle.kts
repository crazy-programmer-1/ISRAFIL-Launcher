plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.israfil.launcher"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.israfil.launcher"
        minSdk = 23
        targetSdk = 32
        versionCode = 1
        versionName = "1.0"
    }
}
