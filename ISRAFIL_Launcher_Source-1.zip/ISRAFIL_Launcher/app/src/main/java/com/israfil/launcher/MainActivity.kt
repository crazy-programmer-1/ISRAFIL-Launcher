package com.israfil.launcher

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import android.text.Editable
import android.text.TextWatcher
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private val bg = Color.rgb(8, 8, 10)
    private val panel = Color.rgb(20, 20, 24)
    private val red = Color.rgb(255, 38, 56)
    private val white = Color.rgb(245, 245, 248)
    private val muted = Color.rgb(160, 160, 170)
    private lateinit var appGrid: GridLayout
    private lateinit var search: EditText
    private data class AppEntry(val label: String, val packageName: String, val icon: android.graphics.drawable.Drawable)
    private var apps: List<AppEntry> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        buildScreen()
        loadApps("")
    }

    private fun rounded(color: Int, stroke: Int = 0): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(18).toFloat()
            if (stroke != 0) setStroke(dp(1), stroke)
        }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun label(text: String, size: Float, color: Int, bold: Boolean = false): TextView =
        TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(12))
            setBackgroundColor(bg)
        }

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val brand = label("ISRAFIL", 27f, red, true)
        top.addView(brand, LinearLayout.LayoutParams(0, -2, 1f))
        top.addView(label("●  SYSTEM UI", 10f, muted, true))
        root.addView(top)

        val tagline = label("DREAM BIG  •  STAY STRONG", 10f, muted, true)
        val tagParams = LinearLayout.LayoutParams(-2, -2)
        tagParams.topMargin = dp(3)
        root.addView(tagline, tagParams)

        val clock = label(SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date()), 46f, white, true)
        val clockParams = LinearLayout.LayoutParams(-2, -2)
        clockParams.topMargin = dp(28)
        root.addView(clock, clockParams)
        val date = label(SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()).format(Date()), 14f, muted)
        root.addView(date)

        val status = TextView(this).apply {
            text = "YOUR PHONE. YOUR STYLE."
            textSize = 10f
            setTextColor(red)
            letterSpacing = 0.16f
            gravity = Gravity.CENTER
            background = rounded(panel, Color.rgb(65, 25, 31))
            setPadding(dp(12), dp(12), dp(12), dp(12))
        }
        val statusParams = LinearLayout.LayoutParams(-1, -2)
        statusParams.topMargin = dp(22)
        root.addView(status, statusParams)

        val appsTitle = label("APPLICATIONS", 12f, white, true)
        val appsParams = LinearLayout.LayoutParams(-1, -2)
        appsParams.topMargin = dp(26)
        root.addView(appsTitle, appsParams)

        search = EditText(this).apply {
            hint = "Search apps..."
            setHintTextColor(muted)
            setTextColor(white)
            textSize = 14f
            singleLine = true
            background = rounded(panel, Color.rgb(55, 55, 62))
            setPadding(dp(15), 0, dp(15), 0)
        }
        val searchParams = LinearLayout.LayoutParams(-1, dp(48))
        searchParams.topMargin = dp(12)
        root.addView(search, searchParams)

        val scroll = ScrollView(this)
        appGrid = GridLayout(this).apply {
            columnCount = 4
            useDefaultMargins = false
            setPadding(0, dp(14), 0, dp(12))
        }
        scroll.addView(appGrid)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val footer = label("ISRAFIL  •  VERSION 1.0", 10f, muted, true).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, dp(4))
        }
        root.addView(footer)

        setContentView(root)
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                loadApps(s?.toString().orEmpty())
            }
            override fun afterTextChanged(s: Editable?) {}
        })
    }

    @Suppress("DEPRECATION")
    private fun loadApps(filter: String) {
        val pm = packageManager
        val intent = Intent(Intent.ACTION_MAIN, null).addCategory(Intent.CATEGORY_LAUNCHER)
        val found = pm.queryIntentActivities(intent, PackageManager.MATCH_ALL)
        apps = found.mapNotNull {
            val ai = it.activityInfo ?: return@mapNotNull null
            try {
                AppEntry(
                    it.loadLabel(pm).toString(),
                    ai.packageName,
                    it.loadIcon(pm)
                )
            } catch (_: Exception) { null }
        }.distinctBy { it.packageName }
            .filter { it.label.contains(filter, ignoreCase = true) }
            .sortedBy { it.label.lowercase(Locale.getDefault()) }

        appGrid.removeAllViews()
        val width = (resources.displayMetrics.widthPixels - dp(40)) / 4
        apps.forEach { app ->
            val cell = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setPadding(dp(3), dp(9), dp(3), dp(9))
                isClickable = true
                isFocusable = true
                setOnClickListener {
                    val launch = pm.getLaunchIntentForPackage(app.packageName)
                    if (launch != null) try { startActivity(launch) } catch (_: Exception) {}
                }
            }
            val icon = ImageView(this).apply {
                setImageDrawable(app.icon)
                scaleType = ImageView.ScaleType.FIT_CENTER
            }
            cell.addView(icon, LinearLayout.LayoutParams(dp(43), dp(43)))
            val name = label(app.label, 10f, white).apply {
                gravity = Gravity.CENTER
                maxLines = 2
                ellipsize = android.text.TextUtils.TruncateAt.END
                setPadding(0, dp(6), 0, 0)
            }
            cell.addView(name, LinearLayout.LayoutParams(-1, dp(32)))
            appGrid.addView(cell, GridLayout.LayoutParams().apply {
                width = width
                height = dp(94)
            })
        }
        if (apps.isEmpty()) {
            val empty = label("No apps found", 14f, muted)
            empty.gravity = Gravity.CENTER
            appGrid.addView(empty, GridLayout.LayoutParams().apply {
                width = width * 4
                height = dp(80)
            })
        }
    }
}
