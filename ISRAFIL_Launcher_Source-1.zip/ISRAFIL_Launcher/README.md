# ISRAFIL Launcher — first prototype

A lightweight Android launcher prototype for the Vivo Y12A (V2102), Android 11.
This is a launcher app, **not a replacement Android OS or custom ROM**.

## Build on a phone using GitHub Actions
1. Create a GitHub repository named `ISRAFIL-Launcher`.
2. Upload all files and folders from this project to the repository root.
3. Open the repository's **Actions** tab and enable workflows if prompted.
4. Run **Build ISRAFIL Launcher APK** (or push a commit to `main`).
5. Open the completed workflow run, download the `ISRAFIL-debug-apk` artifact, and extract it.
6. Install `app-debug.apk`. Android may ask you to allow installation from the browser/files app.
7. Press the phone's Home button and choose **ISRAFIL**. Select it as the default if you want.

## Notes
- The app requests package visibility so it can list launchable apps.
- It does not root the phone, unlock the bootloader, replace Funtouch OS, or change protected system settings.
- This is an early prototype: clock/date are set at launch; next versions can add a wallpaper picker, widgets, dock, and richer visual design.
- Keep the stock launcher available until the prototype is tested.
